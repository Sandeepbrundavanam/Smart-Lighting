import RPi.GPIO as GPIO
import time
from smbus import SMBus

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

GPIO.setup(18, GPIO.OUT)

for _ in range(0, 5):
    p = GPIO.PWM(11, 13)
    p.start(50)
    
    p_avg = 0
    for _ in range(500):
        GPIO.output(10, GPIO.HIGH)
        
        mylcd.led_clear()
        mylcd.led_display_string("Rate: " + str(round(p_avg, 1)), 1, 10)
        
        mylcd.led_display_string("LED CH", 2, 4)
        GPIO.output(15, GPIO.LOW)
        
        mylcd.led_clear()
        mylcd.led_display_string("LDR value: 1")
        
        mylcd.led_display_string(str(round(p_avg)), 1, 10)
        
        mylcd.led_display_string("LED OFF", 2, 4)
    
    p.stop()

myled.icd_clear()
mylcd.icd_display_string("Smart Lighting", 1, 2)
mylcd.icd_display_string("Modes CS", 2, 4)

GPIO.cleanup()